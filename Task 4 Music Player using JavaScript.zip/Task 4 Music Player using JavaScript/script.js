const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const shuffleBtn = document.getElementById('shuffle');
const repeatBtn = document.getElementById('repeat');
const progressContainer = document.getElementById('progress-container');
const progress = document.getElementById('progress');
const currentTimeEl = document.getElementById('current-time');
const durationEl = document.getElementById('duration');
const volumeSlider = document.getElementById('volume');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
const playlistEl = document.getElementById('playlist');
const fileUpload = document.getElementById('fileUpload');
const cover = document.getElementById('cover');
const themeToggle = document.getElementById('theme-toggle');

const songs = [
  {
    title: "Shape Of You",
    artist: "Ed Sheeran",
    src: "songs/song1.mp3",
    cover: "images/cover1.png"
  },
  {
    title: "Blinding Lights",
    artist: "The Weeknd",
    src: "songs/song2.mp3",
    cover: "images/cover2.jpg"
  },
  {
    title: "Perfect",
    artist: "Ed Sheeran",
    src: "songs/song3.mp3",
    cover: "images/cover3.jpg"
  }
];

let currentSong = 0;
let isPlaying = false;
let isShuffle = false;
let isRepeat = false;

// ✅ Function to generate gradient cover with title
function generatePlaceholderCover(title = "No Title") {
  const canvas = document.createElement("canvas");
  canvas.width = 400;
  canvas.height = 250;
  const ctx = canvas.getContext("2d");

  // Gradient background (pink-yellow)
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, '#ffc0cb'); // light pink
  gradient.addColorStop(1, '#fffacd'); // light yellow
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw the title text
  ctx.fillStyle = "#333";
  ctx.font = "bold 20px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const words = title.split(" ");
  let line = "";
  const lines = [];

  for (let i = 0; i < words.length; i++) {
    const testLine = line + words[i] + " ";
    const width = ctx.measureText(testLine).width;
    if (width > 340 && line !== "") {
      lines.push(line);
      line = words[i] + " ";
    } else {
      line = testLine;
    }
  }
  lines.push(line);

  const lineHeight = 26;
  const totalHeight = lines.length * lineHeight;
  const startY = (canvas.height - totalHeight) / 2;

  lines.forEach((l, i) => {
    ctx.fillText(l.trim(), canvas.width / 2, startY + i * lineHeight);
  });

  return canvas.toDataURL("image/png");
}

function loadSong(song) {
  title.textContent = song.title || "Unknown Title";
  artist.textContent = song.artist || "Unknown Artist";
  audio.src = song.src;

  if (song.cover) {
    cover.style.backgroundImage = `url('${song.cover}')`;
  } else {
    const placeholderCover = generatePlaceholderCover(song.title);
    cover.style.backgroundImage = `url('${placeholderCover}')`;
  }

  updatePlaylist();
}

function playPause() {
  if (isPlaying) {
    audio.pause();
    playBtn.textContent = '▶️';
  } else {
    audio.play();
    playBtn.textContent = '⏸️';
  }
  isPlaying = !isPlaying;
}

function nextSong() {
  currentSong = isShuffle
    ? Math.floor(Math.random() * songs.length)
    : (currentSong + 1) % songs.length;
  loadSong(songs[currentSong]);
  audio.play();
  isPlaying = true;
  playBtn.textContent = '⏸️';
}

function prevSong() {
  currentSong = (currentSong - 1 + songs.length) % songs.length;
  loadSong(songs[currentSong]);
  audio.play();
  isPlaying = true;
  playBtn.textContent = '⏸️';
}

function updateProgress() {
  const { duration, currentTime } = audio;
  const percent = (currentTime / duration) * 100;
  progress.style.width = percent + '%';
  currentTimeEl.textContent = formatTime(currentTime);
  durationEl.textContent = formatTime(duration);
}

function setProgress(e) {
  const width = progressContainer.clientWidth;
  const clickX = e.offsetX;
  const duration = audio.duration;
  audio.currentTime = (clickX / width) * duration;
}

function formatTime(time) {
  const mins = Math.floor(time / 60);
  const secs = Math.floor(time % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

function updatePlaylist() {
  playlistEl.innerHTML = '';
  songs.forEach((song, index) => {
    const div = document.createElement('div');
    div.textContent = song.title + ' - ' + song.artist;
    if (index === currentSong) div.classList.add('active');
    div.addEventListener('click', () => {
      currentSong = index;
      loadSong(songs[currentSong]);
      audio.play();
      isPlaying = true;
      playBtn.textContent = '⏸️';
    });
    playlistEl.appendChild(div);
  });
}

// ✅ Update file upload: use real placeholder, not placeholder.com
fileUpload.addEventListener('change', (e) => {
  Array.from(e.target.files).forEach(file => {
    const url = URL.createObjectURL(file);
    const title = file.name.replace(/\.[^/.]+$/, ""); // remove .mp3
    const song = {
      title: title,
      artist: "Unknown Artist",
      src: url,
      cover: null // will generate later dynamically
    };
    songs.push(song);
  });
  updatePlaylist();
});

volumeSlider.addEventListener('input', (e) => {
  audio.volume = e.target.value;
});

themeToggle.addEventListener('change', () => {
  document.body.classList.toggle('light-theme');
});

playBtn.addEventListener('click', playPause);
nextBtn.addEventListener('click', nextSong);
prevBtn.addEventListener('click', prevSong);
shuffleBtn.addEventListener('click', () => isShuffle = !isShuffle);
repeatBtn.addEventListener('click', () => isRepeat = !isRepeat);
audio.addEventListener('ended', () => {
  if (isRepeat) {
    audio.currentTime = 0;
    audio.play();
  } else {
    nextSong();
  }
});
audio.addEventListener('timeupdate', updateProgress);
progressContainer.addEventListener('click', setProgress);

loadSong(songs[currentSong]);
